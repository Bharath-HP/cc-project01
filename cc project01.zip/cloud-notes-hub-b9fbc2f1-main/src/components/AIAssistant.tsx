import { useState } from 'react';
import { Sparkles, FileText, Lightbulb, Wand2, List, ChevronDown, X, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { ScrollArea } from '@/components/ui/scroll-area';
import { useToast } from '@/hooks/use-toast';

interface AIAssistantProps {
  noteTitle: string;
  noteContent: string;
  onApplyContent: (content: string) => void;
}

type AIAction = 'summarize' | 'expand' | 'improve' | 'ideas' | 'outline';

const AI_ACTIONS = [
  { id: 'summarize' as AIAction, label: 'Summarize', icon: FileText, description: 'Create a brief summary' },
  { id: 'expand' as AIAction, label: 'Expand', icon: Wand2, description: 'Add more details' },
  { id: 'improve' as AIAction, label: 'Improve Writing', icon: Sparkles, description: 'Enhance clarity & style' },
  { id: 'ideas' as AIAction, label: 'Generate Ideas', icon: Lightbulb, description: 'Get related ideas' },
  { id: 'outline' as AIAction, label: 'Create Outline', icon: List, description: 'Structure the content' },
];

export function AIAssistant({ noteTitle, noteContent, onApplyContent }: AIAssistantProps) {
  const [isLoading, setIsLoading] = useState(false);
  const [result, setResult] = useState<string>('');
  const [currentAction, setCurrentAction] = useState<AIAction | null>(null);
  const { toast } = useToast();

  const handleAction = async (action: AIAction) => {
    if (!noteContent.trim()) {
      toast({
        title: 'Note is empty',
        description: 'Please add some content to your note first.',
        variant: 'destructive',
      });
      return;
    }

    setIsLoading(true);
    setCurrentAction(action);
    setResult('');

    try {
      const response = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/note-ai`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY}`,
        },
        body: JSON.stringify({
          action,
          noteTitle,
          noteContent,
        }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to process request');
      }

      if (!response.body) {
        throw new Error('No response body');
      }

      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let buffer = '';
      let fullResult = '';

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        buffer += decoder.decode(value, { stream: true });

        let newlineIndex;
        while ((newlineIndex = buffer.indexOf('\n')) !== -1) {
          let line = buffer.slice(0, newlineIndex);
          buffer = buffer.slice(newlineIndex + 1);

          if (line.endsWith('\r')) line = line.slice(0, -1);
          if (line.startsWith(':') || line.trim() === '') continue;
          if (!line.startsWith('data: ')) continue;

          const jsonStr = line.slice(6).trim();
          if (jsonStr === '[DONE]') break;

          try {
            const parsed = JSON.parse(jsonStr);
            const content = parsed.choices?.[0]?.delta?.content;
            if (content) {
              fullResult += content;
              setResult(fullResult);
            }
          } catch {
            buffer = line + '\n' + buffer;
            break;
          }
        }
      }
    } catch (error: any) {
      console.error('AI error:', error);
      toast({
        title: 'AI Error',
        description: error.message || 'Failed to process your request',
        variant: 'destructive',
      });
      setResult('');
      setCurrentAction(null);
    } finally {
      setIsLoading(false);
    }
  };

  const handleApply = () => {
    if (currentAction === 'improve' || currentAction === 'expand') {
      onApplyContent(result);
      toast({
        title: 'Applied!',
        description: 'The AI suggestion has been applied to your note.',
      });
    } else {
      onApplyContent(noteContent + '\n\n---\n\n' + result);
      toast({
        title: 'Added!',
        description: 'The AI content has been added to your note.',
      });
    }
    setResult('');
    setCurrentAction(null);
  };

  const handleClose = () => {
    setResult('');
    setCurrentAction(null);
  };

  if (result || isLoading) {
    return (
      <div className="border-t border-border bg-card animate-slide-up">
        <div className="flex items-center justify-between px-4 py-2 border-b border-border">
          <div className="flex items-center gap-2">
            <Sparkles className="h-4 w-4 text-primary" />
            <span className="font-medium text-sm">
              {AI_ACTIONS.find(a => a.id === currentAction)?.label}
            </span>
            {isLoading && <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" />}
          </div>
          <div className="flex items-center gap-2">
            {result && !isLoading && (
              <Button size="sm" onClick={handleApply} className="gap-1">
                <Wand2 className="h-3 w-3" />
                Apply
              </Button>
            )}
            <Button size="icon" variant="ghost" onClick={handleClose} className="h-7 w-7">
              <X className="h-4 w-4" />
            </Button>
          </div>
        </div>
        <ScrollArea className="h-48">
          <div className="p-4 text-sm leading-relaxed whitespace-pre-wrap">
            {result || 'Thinking...'}
          </div>
        </ScrollArea>
      </div>
    );
  }

  return (
    <div className="px-4 py-3 border-t border-border bg-card/50">
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="outline" size="sm" className="gap-2">
            <Sparkles className="h-4 w-4 text-primary" />
            AI Assistant
            <ChevronDown className="h-3 w-3" />
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="start" className="w-56">
          {AI_ACTIONS.map(action => (
            <DropdownMenuItem
              key={action.id}
              onClick={() => handleAction(action.id)}
              className="flex items-start gap-3 py-2"
            >
              <action.icon className="h-4 w-4 mt-0.5 text-primary" />
              <div>
                <div className="font-medium">{action.label}</div>
                <div className="text-xs text-muted-foreground">{action.description}</div>
              </div>
            </DropdownMenuItem>
          ))}
        </DropdownMenuContent>
      </DropdownMenu>
    </div>
  );
}
