import { useState, useEffect, useRef, useCallback } from 'react';
import { Note } from '@/hooks/useNotes';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { FileText, Save } from 'lucide-react';
import { format } from 'date-fns';
import { AIAssistant } from './AIAssistant';

interface NoteEditorProps {
  note: Note | null;
  onUpdate: (id: string, updates: Partial<Pick<Note, 'title' | 'content'>>) => Promise<Note | null>;
}

export function NoteEditor({ note, onUpdate }: NoteEditorProps) {
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [isSaving, setIsSaving] = useState(false);
  const saveTimeoutRef = useRef<NodeJS.Timeout>();

  useEffect(() => {
    if (note) {
      setTitle(note.title);
      setContent(note.content);
    }
  }, [note?.id]);

  const debouncedSave = useCallback(
    (updates: Partial<Pick<Note, 'title' | 'content'>>) => {
      if (!note) return;
      
      if (saveTimeoutRef.current) {
        clearTimeout(saveTimeoutRef.current);
      }

      setIsSaving(true);
      saveTimeoutRef.current = setTimeout(async () => {
        await onUpdate(note.id, updates);
        setIsSaving(false);
      }, 500);
    },
    [note, onUpdate]
  );

  const handleTitleChange = (value: string) => {
    setTitle(value);
    debouncedSave({ title: value });
  };

  const handleContentChange = (value: string) => {
    setContent(value);
    debouncedSave({ content: value });
  };

  const handleApplyAIContent = (newContent: string) => {
    setContent(newContent);
    if (note) {
      onUpdate(note.id, { content: newContent });
    }
  };

  // Calculate word count and reading time
  const wordCount = content.trim() ? content.trim().split(/\s+/).length : 0;
  const readingTime = Math.max(1, Math.ceil(wordCount / 200));

  if (!note) {
    return (
      <div className="flex-1 flex items-center justify-center bg-background">
        <div className="text-center animate-fade-in">
          <FileText className="h-16 w-16 mx-auto mb-4 text-muted-foreground/30" />
          <h2 className="font-serif text-2xl font-medium text-muted-foreground mb-2">
            Select a note
          </h2>
          <p className="text-muted-foreground/70">
            Choose a note from the sidebar or create a new one
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 flex flex-col bg-background overflow-hidden animate-fade-in">
      {/* Editor Header */}
      <div className="flex items-center justify-between px-8 py-4 border-b border-border">
        <div className="flex items-center gap-4 text-sm text-muted-foreground">
          <span>Last edited {format(new Date(note.updated_at), 'MMM d, yyyy \'at\' h:mm a')}</span>
          <span className="hidden sm:inline">•</span>
          <span className="hidden sm:inline">{wordCount} words</span>
          <span className="hidden sm:inline">•</span>
          <span className="hidden sm:inline">{readingTime} min read</span>
        </div>
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          {isSaving ? (
            <>
              <Save className="h-4 w-4 animate-pulse" />
              <span>Saving...</span>
            </>
          ) : (
            <>
              <Save className="h-4 w-4" />
              <span>Saved</span>
            </>
          )}
        </div>
      </div>

      {/* Editor Content */}
      <div className="flex-1 overflow-auto">
        <div className="max-w-3xl mx-auto px-8 py-8">
          <Input
            value={title}
            onChange={e => handleTitleChange(e.target.value)}
            placeholder="Note title..."
            className="text-3xl font-serif font-semibold border-none shadow-none focus-visible:ring-0 px-0 mb-4 placeholder:text-muted-foreground/40"
          />
          <Textarea
            value={content}
            onChange={e => handleContentChange(e.target.value)}
            placeholder="Start writing..."
            className="min-h-[calc(100vh-380px)] resize-none border-none shadow-none focus-visible:ring-0 px-0 text-lg leading-relaxed placeholder:text-muted-foreground/40"
          />
        </div>
      </div>

      {/* AI Assistant */}
      <AIAssistant
        noteTitle={title}
        noteContent={content}
        onApplyContent={handleApplyAIContent}
      />
    </div>
  );
}