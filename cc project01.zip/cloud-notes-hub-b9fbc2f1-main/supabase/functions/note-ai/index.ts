import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { action, noteContent, noteTitle } = await req.json();
    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    
    if (!LOVABLE_API_KEY) {
      throw new Error("LOVABLE_API_KEY is not configured");
    }

    let systemPrompt = "";
    let userPrompt = "";

    switch (action) {
      case "summarize":
        systemPrompt = "You are a helpful assistant that summarizes notes concisely. Keep summaries brief but capture all key points. Use bullet points when appropriate.";
        userPrompt = `Please summarize this note titled "${noteTitle}":\n\n${noteContent}`;
        break;
      case "expand":
        systemPrompt = "You are a creative writing assistant. Expand on the given content with more details, examples, and explanations while maintaining the original tone and style.";
        userPrompt = `Please expand on this note titled "${noteTitle}" with more details and depth:\n\n${noteContent}`;
        break;
      case "improve":
        systemPrompt = "You are an expert editor. Improve the writing quality, fix grammar, enhance clarity, and make the content more engaging while preserving the original meaning and voice.";
        userPrompt = `Please improve the writing quality of this note titled "${noteTitle}":\n\n${noteContent}`;
        break;
      case "ideas":
        systemPrompt = "You are a creative brainstorming assistant. Generate related ideas, questions to explore, or next steps based on the content. Be creative and insightful.";
        userPrompt = `Based on this note titled "${noteTitle}", suggest related ideas, questions to explore, or next steps:\n\n${noteContent}`;
        break;
      case "outline":
        systemPrompt = "You are a content organization expert. Create a well-structured outline with clear headings and subpoints that would help organize the content better.";
        userPrompt = `Create a structured outline for organizing this note titled "${noteTitle}":\n\n${noteContent}`;
        break;
      default:
        throw new Error(`Unknown action: ${action}`);
    }

    console.log(`Processing AI action: ${action} for note: ${noteTitle}`);

    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash",
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: userPrompt },
        ],
        stream: true,
      }),
    });

    if (!response.ok) {
      if (response.status === 429) {
        return new Response(JSON.stringify({ error: "Rate limit exceeded. Please try again in a moment." }), {
          status: 429,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      if (response.status === 402) {
        return new Response(JSON.stringify({ error: "AI usage limit reached. Please add credits to continue." }), {
          status: 402,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      const errorText = await response.text();
      console.error("AI gateway error:", response.status, errorText);
      throw new Error(`AI gateway error: ${response.status}`);
    }

    return new Response(response.body, {
      headers: { ...corsHeaders, "Content-Type": "text/event-stream" },
    });
  } catch (error) {
    console.error("Error in note-ai function:", error);
    return new Response(JSON.stringify({ error: error instanceof Error ? error.message : "Unknown error" }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
